import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

// Helper to encode file to base64
export const fileToGenerativePart = async (file: File): Promise<{ inlineData: { data: string; mimeType: string } }> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      // Remove data url prefix (e.g. "data:image/jpeg;base64,")
      const base64Data = base64String.split(',')[1];
      resolve({
        inlineData: {
          data: base64Data,
          mimeType: file.type
        }
      });
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

export const chatWithGemini = async (prompt: string, history: { role: string, parts: { text: string }[] }[] = []): Promise<string> => {
  if (!apiKey) throw new Error("API Key not found");

  try {
    const chat = ai.chats.create({
        model: 'gemini-3-pro-preview',
        history: history,
        config: {
            systemInstruction: "You are 'Marvin', an elite AI fitness coach for the Fitmarvin platform. You are motivating, knowledgeable about physiology, nutrition, and exercise science. Keep answers concise and action-oriented."
        }
    });

    const result: GenerateContentResponse = await chat.sendMessage({ message: prompt });
    return result.text || "No response generated.";
  } catch (error) {
    console.error("Gemini Chat Error:", error);
    throw error;
  }
};

export const analyzeMediaWithGemini = async (file: File, prompt: string): Promise<string> => {
    if (!apiKey) throw new Error("API Key not found");

    try {
        const filePart = await fileToGenerativePart(file);

        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-3-pro-preview',
            contents: {
                parts: [
                    filePart,
                    { text: prompt }
                ]
            }
        });

        return response.text || "Could not analyze the media.";
    } catch (error) {
        console.error("Gemini Analysis Error:", error);
        throw error;
    }
}
